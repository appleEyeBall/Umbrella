package com.example.olase.umbrella.Activities;

import android.app.Activity;
import android.os.Bundle;

import com.example.olase.umbrella.R;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        

    }
}
